## ***PROGRAMAÇÃO C#***



var= variável que pode mudar seu estado

const = contante não muda

and = E =\&\&

or = ou = ||

== comparação

=atribuição

!= atribuição









inicio

var n1 = 0;

var n2 = 0;





escreva("informeumnumero");

leia n1;

escreva("informeoutronumero");

leia n2;



var media = n1+n2;

escreva(media);

soma<-n1+n2

escreva"a soma é " soma:





fim

