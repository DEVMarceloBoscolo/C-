﻿Console.WriteLine("de 1 a 30:");


for (int i = 1; i <= 30; i++)

    if (i % 2 != 0)  
    {
        Console.WriteLine(i);
    }
/* se tirarmos o if teremos so a contagem*/