﻿Console.WriteLine("Multiplicação de dois numeros");

Console.Write("digite um numero: ");
double n1 = double.Parse(Console.ReadLine());
Console.Write("digite outro numero:");
double n2 = double.Parse(Console.ReadLine());

double mult = n1 * n2;

Console.WriteLine($"\n A multiplicação é :  {mult} ");
