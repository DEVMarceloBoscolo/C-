﻿ Console.WriteLine("Contando de 1 a 50, somente os números pares:");

    for (int i = 1; i <= 50; i++)
    {
        if (i % 2 == 0)
        {
            Console.WriteLine(i);
        }
    }
