﻿Console.WriteLine("O dobro do numero informado é :");

Console.Write("digite um numero: ");
double n1 = double.Parse(Console.ReadLine());

double dobro = n1 * 2;
Console.WriteLine($"o dobro do numero digitado é : {dobro}");
