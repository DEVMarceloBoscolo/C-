﻿/*int nota_1, nota_2, nota_3, nota_4, media;

Console.WriteLine( " informe a primeira not:  ");
nota_1 = int.Parse(Console.ReadLine());
Console.WriteLine("informe a segunda nota:  ");
nota_2 = Convert.ToInt32(Console.ReadLine());
Console.Write(" informe a terceira nota:  ");
nota_3 = int.Parse(Console.ReadLine());
Console.WriteLine("informe a quarta nota :  ");
nota_4 = Convert.ToInt32(Console.ReadLine());

media = (nota_1 + nota_2 + nota_3 + nota_4) / 4;


if (media >= 7)
{
    Console.WriteLine("aluno aprovado");
}
else
{
    Console.WriteLine("Aluno reprovado");
}


if (media >= 7)
    Console.WriteLine("aluno aprovado");
else
    Console.WriteLine("Aluno reprovado");

string resultado = media >= 7 ? "aluno aprovado" : "aluno reprovado"; //operador ternario
Console.WriteLine(resultado);
*/




/*int temperatura = 30;

if(temperatura > 35)
{
    Console.WriteLine("esta muito quente!");
}
else if (temperatura >= 25)
{
    Console.WriteLine("o clima esta agradavel.");
}
else
{
    Console.WriteLine("esta frio!");
}*/


// comentario em linha

/*
 comentario de multiplas linhas.
 */


/*
int idade = 20;

bool possuicarteira = true;

if (idade>=18 && possuicarteira)
{
    Console.Write("voce pode dirigir.");
}
else
{
    Console.WriteLine("voce nao pode dirigir.");
}
*/
/*
int numero = 10;
string resultado = (numero % 2 == 0) ? "par" : "impar";
Console.Write(resultado);
*/

int opcao = 2;
switch (opcao)
{
    case 1:
        Console.WriteLine("opcao 1");
        break;
    case 2:
        Console.WriteLine("opcao 2");
        break;
    case 3:
        Console.WriteLine("opcao 3");
        break;

    default:
        Console.WriteLine("opcao invalida.");
        break;
}