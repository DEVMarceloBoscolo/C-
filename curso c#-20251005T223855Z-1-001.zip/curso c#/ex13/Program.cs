﻿Console.WriteLine("Calculo de meida de 4 notas");

Console.Write("digite a 1º nota:");
double n1 = double.Parse(Console.ReadLine());
Console.Write("digite a 2º nota:");
double n2 = double.Parse(Console.ReadLine());
Console.Write("digite a 3º nota:");
double n3 = double.Parse(Console.ReadLine());
Console.Write("digite a 4º nota:");
double n4 = double.Parse(Console.ReadLine());

double media = (n1 + n2 + n3 + n4) / 4;

if (media >= 7)
{
    Console.WriteLine("\n Aprovado");
}
else
{
    Console.WriteLine("\n Reprovado");
}

Console.Write($"\n A media é {media} ");


