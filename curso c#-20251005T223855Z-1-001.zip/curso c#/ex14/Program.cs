﻿Console.WriteLine("Positivo / Negativo / zero");

Console.Write("Digite um numero:");
double n1 = double.Parse(Console.ReadLine());

if ( n1 > 0)
{
    Console.WriteLine("o numero é positivo");
}
else if ( n1  < 0){
    Console.WriteLine(" o numero é negativo");
}
else
{
    Console.WriteLine("o numero e 0 ");
}