﻿Console.WriteLine("hello word! me livrei da maldição!");
