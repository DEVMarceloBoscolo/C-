﻿Console.WriteLine("VERIFICADOR DE IDADE:  ");

Console.Write("digite uma idade: ");
int n1 = int.Parse(Console.ReadLine());

if (n1>=18)
{
    Console.WriteLine("      \n         ====Maior de Idade====         ");
}
else
{
    Console.WriteLine("       \n        ==== Menor de Idade ====         ");
}
