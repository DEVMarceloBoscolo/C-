﻿Console.WriteLine("Calculo da area de triangulos: ");

Console.WriteLine("me informe o maior lado do triangulo:");
double n1 = double.Parse(Console.ReadLine());
Console.WriteLine("me informe o outro lado do triangulo:");
double n2 = double.Parse(Console.ReadLine());
Console.WriteLine("me informe o ultimo lado: ");
double n3 = double.Parse(Console.ReadLine());

double altura = ((n1 * n2 * n3) * 1.732 / 2);

double area = (n1 * altura / 2);
Console.WriteLine($"\n a area do triangulo é: {area} ");
