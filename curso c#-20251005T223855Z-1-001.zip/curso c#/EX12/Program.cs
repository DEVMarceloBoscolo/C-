﻿  int numero;

 Console.Write("Digite um número para ver sua tabuada: ");

        try
        {
            numero = int.Parse(Console.ReadLine());
        }
        catch (FormatException)
        {
            Console.WriteLine("Entrada inválida. Por favor, digite um número inteiro.");
            return; 
         }

        Console.WriteLine($"\nTabuada de {numero}:");
        Console.WriteLine("--------------------");

        for (int i = 1; i <= 10; i++)
        {
            int resultado = numero * i;
            Console.WriteLine($"{numero} x {i} = {resultado}");
        }
    
