﻿/*int opcao;
double n1, n2, resultado;
string nome;
Console.Write("informe seu nome: ");
nome = Console.ReadLine();
Console.WriteLine("  ola "   +     nome      +    "informe o primeiro numero: ");
n1 = double.Parse(Console.ReadLine());
Console.Write("informe o segundo numero: ");
n2 = double.Parse(Console.ReadLine());
Console.WriteLine("selecione uma opção: ");
Console.WriteLine("1 - somar ");
Console.WriteLine("2 - subtrair");
Console.WriteLine("3 - multiplicar");
Console.WriteLine("4 - dividir");
Console.Write("informe a opção desejada: ");
opcao = int.Parse(Console.ReadLine());


switch (opcao)
{
    case 1:
        resultado = n1 + n2;
        Console.WriteLine($"a soma de {n1} +{n2} = {resultado}");
        break;
    case 2:
        resultado = n1 - n2;
        Console.WriteLine($"a subtração de {n1} - {n2} = {resultado}");
        break;
    case 3:
        resultado = n1 * n2;
        Console.WriteLine($"a multiplicação de {n1} X {n2}= {resultado}");
        break;
    case 4:
        resultado = n1 / n2;
        Console.WriteLine($"a divisão de {n1} / {n2} = {resultado}");
        break;
    default:
        Console.WriteLine("opcao não existe :( ");
        break;

}
 /*place holders
  concatenção
 iterpolação*/


/*int opcao;

Console.Write("1 - Frase \n" );       
Console.Write("2 - Texto \n" );
opcao = int.Parse(Console.ReadLine());

string mensagem = opcao switch
{
    1 => "bom dia",
    2 => "neste dia tao importente estamos proximos a aprender mais.",
    _ => "opção invalida"
};

Console.WriteLine(mensagem);

/*      \n     quebra de linha  */


/*
for (int i = 1; i <= 10; i++)
{
    Console.WriteLine(i);
}*/

/*for (int i = 10; i >= 1; i--)
{
    Console.WriteLine(i);
}*/