# Console Bank
Sistema bancário simples em C# para operações básicas.
Desenvolvido por marceloboscolo.