# TodoList CLI
Gerenciador de tarefas em C# via console.
Desenvolvido por marceloboscolo.