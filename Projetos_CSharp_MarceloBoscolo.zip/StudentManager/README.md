# StudentManager
Sistema de gerenciamento de alunos e notas em C#.
Desenvolvido por marceloboscolo.